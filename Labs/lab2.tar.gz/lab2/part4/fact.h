extern int fact(int);
